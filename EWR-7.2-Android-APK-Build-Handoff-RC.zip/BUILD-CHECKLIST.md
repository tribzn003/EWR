# APK Build Checklist

- [ ] EAS account authenticated
- [ ] Android package identifier available: `com.ewr.earthworldranking`
- [ ] Android signing credentials configured by EAS
- [ ] `eas build -p android --profile preview`
- [ ] Build succeeds
- [ ] APK installed on physical Android device
- [ ] Register/login tested
- [ ] Ranking tested
- [ ] Sandbox/IAP test completed
- [ ] Failed/cancelled payment does not change rank
