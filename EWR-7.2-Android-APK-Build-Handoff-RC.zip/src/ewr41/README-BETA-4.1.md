# EWR Beta 4.1 — Native IAP RC

This package upgrades Beta 4.0 with native store purchase integration through `expo-iap` / OpenIAP.

- Android: Google Play Billing purchase → secure EWR backend verification.
- iOS: StoreKit purchase/JWS → secure EWR backend verification.
- Product IDs are allowlisted server-side and client-side.
- Credits are never granted by the client.
- The transaction is only finished after backend verification succeeds.
- Pending/failed/unverified purchases do not change ranking.

Official platform guidance confirms that Google recommends sending purchase tokens to a secure backend and granting entitlements only after verification; Apple recommends the modern StoreKit In-App Purchase API and provides signed transaction data plus the App Store Server API for server-side transaction management. citeturn0search4turn0search5turn0search1turn0search2

This is an RC source package. No APK/IPA is claimed because this environment has no Android SDK/store credentials.
