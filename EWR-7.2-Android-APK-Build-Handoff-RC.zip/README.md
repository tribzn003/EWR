# EWR 7.2 — Android APK Build Handoff

Final handoff package for producing the installable Android APK from the EWR native-IAP mobile source.

## Build
1. `cd mobile`
2. `npm install`
3. `eas login`
4. `eas build -p android --profile preview`

The preview profile is intended to produce an installable APK. Production store builds should use the AAB profile.

## Important
- This package is source/build configuration, not a prebuilt APK.
- Native IAP requires a development/standalone build; Expo Go is not sufficient.
- Backend payment verification must be configured before real purchases can affect ranking.
